import AdminLayout from "@/app/adminLayout";


export default function Layout({ children }) {
  return <AdminLayout>{children}</AdminLayout>;
}
