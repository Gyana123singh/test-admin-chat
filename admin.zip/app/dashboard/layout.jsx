import AdminLayout from "../adminLayout";


export default function Layout({ children }) {
  return <AdminLayout>{children}</AdminLayout>;
}
